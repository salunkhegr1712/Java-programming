package org.example;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructType;

import java.util.concurrent.TimeoutException;

import static org.apache.spark.sql.functions.avg;

public class Another {
    public static void main(String[] args) {
        // Create Spark Session
        SparkSession spark = SparkSession.builder()
                .appName("SparkStructuredStreamingExample")
                .master("local[2]") // You can change this based on your cluster setup
                .getOrCreate();

        // Define the schema for the streaming data
        StructType schema = new StructType()
                .add("device_id", "integer")
                .add("temperature", "integer")
                .add("timestamp", "string");

        // Create a streaming DataFrame with a CSV source
        Dataset<Row> streamingDF = spark.readStream()
                .option("header", "true")
                .schema(schema)
                .csv("Resources/input");

        // Calculate the average temperature for each device using a GroupedDataset
        Dataset<Row> resultDF = streamingDF.groupBy("device_id")
                .agg(avg("temperature").as("avg_temperature"));

        // Join the result DataFrame with the original streaming DataFrame on 'device_id'
        Dataset<Row> finalDF = streamingDF
                .join(resultDF, "device_id")
                .select("device_id", "temperature", "timestamp", "avg_temperature");


        try {
            // Define the query to output the result to the console (you can modify this based on your needs)
            StreamingQuery query = finalDF.writeStream()
                    .outputMode("append")
                    .format("console")
                    .start();

            // Wait for the query to terminate (Ctrl+C to stop if running in the console)
            query.awaitTermination();

        } catch (Exception x) {
            x.printStackTrace();
        }

    }

}