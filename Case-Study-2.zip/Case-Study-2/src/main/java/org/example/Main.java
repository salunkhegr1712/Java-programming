package org.example;

import org.apache.spark.sql.Dataset;
import org.apache.spark.sql.Row;
import org.apache.spark.sql.SparkSession;
import org.apache.spark.sql.functions;
import org.apache.spark.sql.streaming.StreamingQuery;
import org.apache.spark.sql.streaming.StreamingQueryException;
import org.apache.spark.sql.types.DataTypes;
import org.apache.spark.sql.types.StructType;
import java.util.concurrent.TimeoutException;


public class Main {
    public static void main(String[] args) throws StreamingQueryException, TimeoutException {
        SparkSession spark = SparkSession
                .builder().master("local[*]")
                .appName("SparkStreamingExample")
                .getOrCreate();

        spark.sparkContext().setLogLevel("WARN");
        StructType tempDataSchema = new StructType()
                .add("device_id", DataTypes.IntegerType)
                .add("temperature", DataTypes.DoubleType)
                .add("timestamp", DataTypes.TimestampType);

        StructType maxTempSchema = new StructType()
                .add("device_id", DataTypes.IntegerType)
                .add("max_temp", DataTypes.DoubleType);


//        get a stream dataset with readstream
        Dataset<Row> temperatureStreamDataset = spark
                .readStream()
                .schema(tempDataSchema)
                .option("header", "true")
                .csv("Resources/input");

//        a static dataset
        Dataset<Row> maxTemperatureDataset = spark
                .read()
                .schema(maxTempSchema)
                .option("header", "true")
                .csv("Resources/max_temperature_for_device.csv");


        Dataset<Row> joinedDataset=temperatureStreamDataset.join(maxTemperatureDataset,"device_id").filter("temperature > max_temp");

        Dataset<Row> joinedDatasetAverage=temperatureStreamDataset.groupBy("device_id")
                .agg(functions.avg("temperature").alias("average_temperature"));


        try {
            StreamingQuery query1 = joinedDataset.writeStream()
                    .outputMode("append")
                    .format("console")
                    .start();

            StreamingQuery query2 = joinedDatasetAverage.writeStream()
                    .outputMode("complete")
                    .format("console")
                    .start();

            query1.awaitTermination();
            query2.awaitTermination();
        }
        catch (Exception e){
            e.printStackTrace();
        }


    }
}